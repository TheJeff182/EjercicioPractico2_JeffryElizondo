package com.example.demo.service;

import com.example.demo.domain.Usuario;
import com.example.demo.repository.UsuarioRepository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<Usuario> getUsuarios() {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> getUsuario(Long id) {
        return usuarioRepository.findById(id);
    }

    public void save(Usuario usuario) {
        usuarioRepository.save(usuario);
    }

    public void delete(Long id) {
        usuarioRepository.deleteById(id);
    }

    // Consultas avanzadas
    public List<Usuario> buscarPorRol(Long rolId) {
        return usuarioRepository.findByRol_Id(rolId);
    }

    public List<Usuario> buscarPorRangoFechas(LocalDateTime desde, LocalDateTime hasta) {
        return usuarioRepository.findByFechaCreacionBetween(desde, hasta);
    }

    public List<Usuario> buscarPorNombre(String texto) {
        return usuarioRepository.findByNombreContainingIgnoreCase(texto);
    }
}
