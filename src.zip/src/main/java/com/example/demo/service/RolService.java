package com.example.demo.service;

import com.example.demo.domain.Rol;
import com.example.demo.repository.RolRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class RolService {

    private final RolRepository rolRepository;

    public RolService(RolRepository rolRepository) {
        this.rolRepository = rolRepository;
    }

    public List<Rol> getRoles() {
        return rolRepository.findAll();
    }

    public Optional<Rol> getRol(Long id) {
        return rolRepository.findById(id);
    }

    public void save(Rol rol) {
        rolRepository.save(rol);
    }

    public void delete(Long id) {
        rolRepository.deleteById(id);
    }
}
